%% Tensão e corrente dos painéis (48 horas)
tempo = 0:1:48;

% Índices para as 24h originais
n1 = [1,2,3,4,5,20,21,22,23,24,25];
a1 = [6,7]; b1 = [8,9]; c1 = [10,11]; d1 = [12,13];
e1 = [14,15]; f1 = [16,17]; g1 = [18,19];

% Criar vetores de 48 horas
Tensao = zeros(1,49);
Corrente = zeros(1,49);

%% --- PRIMEIRO DIA (0–24h) ---

Tensao(n1) = 0;
Corrente(n1) = 0;

Tensao(a1) = 421.838;  Corrente(a1) = 80.8392;
Tensao(b1) = 430.796;  Corrente(b1) = 201.976;
Tensao(c1) = 431.538;  Corrente(c1) = 323.228;
Tensao(d1) = 431.1;    Corrente(d1) = 403.5;
Tensao(e1) = 431.538;  Corrente(e1) = 323.228;
Tensao(f1) = 431.381;  Corrente(f1) = 242.453;
Tensao(g1) = 426.532;  Corrente(g1) = 121.251;

%% --- SEGUNDO DIA (24–48h) ---
% Basta somar +24 a todos os índices e repetir

offset = 24;

Tensao(n1+offset) = 0;
Corrente(n1+offset) = 0;

Tensao(a1+offset) = 421.838;  Corrente(a1+offset) = 80.8392;
Tensao(b1+offset) = 430.796;  Corrente(b1+offset) = 201.976;
Tensao(c1+offset) = 431.538;  Corrente(c1+offset) = 323.228;
Tensao(d1+offset) = 431.1;    Corrente(d1+offset) = 403.5;
Tensao(e1+offset) = 431.538;  Corrente(e1+offset) = 323.228;
Tensao(f1+offset) = 431.381;  Corrente(f1+offset) = 242.453;
Tensao(g1+offset) = 426.532;  Corrente(g1+offset) = 121.251;

Potencia_PV = Tensao .* Corrente;

%% Curva de carga (48 horas)
carga24 = [5 5 10 15 20 50 50 70 70 75 80 85 ...
           85 90 110 130 130 115 70 50 40 35 20 10 5];

% Repete a curva para 48 horas
carga = [carga24(1:end-1) carga24] * 1e3;

% %% Energia da bateria
% 
% Potencia_baterias = (carga-Potencia_PV);
% indx1 = Potencia_baterias > 0;
% indx2 = Potencia_baterias < 0;
% Potencia_baterias_descarga = zeros(1,25);
% Potencia_baterias_carga = zeros(1,25);
% Potencia_baterias_descarga(indx1) = Potencia_baterias(indx1);
% Potencia_baterias_carga(indx2) = Potencia_baterias(indx2);
% 
% P_desc = Potencia_baterias_descarga / 1e3;
% P_carg = Potencia_baterias_carga / 1e3;     
% 
% % Energia = soma(Potencia * Δt) com Δt = 1h
% Energia_descarga = sum(P_desc * 1)
% Energia_carga = sum(abs(P_carg) * 1)   
% 
% %% Plot das figuras
% % figure('Name', 'Curva de Carga Diaria');
% hold off
% figure(2)
% %subplot(2,1,1)
% plot(tempo,carga/1e3);
% title('Curva de Carga Diaria'); 
% xlabel('Hora do Dia'); 
% ylabel('Potencia [kW]');
% grid on;
% %subplot(2,1,2)
% %plot(tempo,carga/1e3);
% hold on
% %plot(tempo,Potencia_PV/1e3)
% %plot(tempo,(Potencia_baterias_descarga)/1e3)
% %plot(tempo,abs(Potencia_baterias_carga)/1e3)
% title('Curva de Carga Diaria');  
% xlabel('Hora do Dia'); 
% ylabel('Potencia [kW]');
% grid on;
% legend('Carga','Geração PV')
% 
% figure(1)
% subplot(3,1,1)
% plot(tempo,Tensao)
% grid on
% title('Tensão dos painéis durante o dia')
% ylabel('Tensão[V]')
% xlabel('Tempo[horas]')
% 
% subplot(3,1,2)
% plot(tempo,Corrente)
% grid on
% title('Corrente dos painéis durante o dia')
% ylabel('Corrente[A]')
% xlabel('Tempo[horas]')
% 
% subplot(3,1,3)
% plot(tempo,Potencia_PV/1e3)
% grid on
% title('Potência dos painéis durante o dia')
% ylabel('Potência[kW]')
% xlabel('Tempo[horas]')

%% Exportar dados para Simulink

tempo = tempo * 3600;     % converter horas → segundos

TensaoTs  = timeseries(Tensao,  tempo);
CorrenteTs = timeseries(Corrente, tempo);
CargaTs    = timeseries(carga,    tempo);