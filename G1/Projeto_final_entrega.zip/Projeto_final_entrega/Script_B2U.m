clc; clear all; close all;

%% Defini��o dos Par�metros de Projeto
Vs = 300;
Vo = 800;
P = 5000;
deli = 0.4;
delv = 0.05;
fc = 50000;

%% C�lculo do indutor
D = 1-(Vs/Vo);
D_l = 1-D;
iL = P/Vs;
deliL = deli*iL;
L_proj = Vs*D/(fc*deliL)
L = 300e-6

%% C�lculo do capacitor
io = P/Vo;
delvC = Vo*delv;
C_proj = io*D/(fc*delvC)
C = 2.2e-6 %

%% C�lculo da carga
R = Vo/io;

%% Defini��o dos Par�metros de Simula��o
Vs_sim = 630;
Vo_sim = 800;
P_sim = 5000;
io_sim = P_sim/Vo_sim;
R_sim = Vo_sim/io_sim;
D_sim = Vs_sim/Vo_sim;
% D_sim = 1-(Vs_sim/Vo_sim);

%% Projeto do filtro passa baixa

[NUMd,DENd] = c2dm(2*pi*5,[1 2*pi*5],1/fc,'tustin')
[NUMd2,DENd2] = c2dm(2*pi*50,[1 2*pi*50],1/fc,'tustin')
[NUMd3,DENd3] = c2dm(2*pi*500,[1 2*pi*500],1/fc,'tustin')
[NUMd_1k6,DENd_1k6] = c2dm(10e3,[1 10e3],1/fc,'tustin')

%% Dados Bateria de niquel
SOC_niquel = [5 10 15 20 25 30 40 50 60 70 80 90 100];
U_oc_niquel_desc = [565.8413279 571.5206188 589.5147246 615.4492301 616.2674099 616.4374415 616.7778948 617.7663012 617.9445224 618.6088548 618.9493081 619.4514084 624.3287037];
U_oc_niquel_carg = [565.8413279	609.1132114	617.2230579	617.7175536	618.2116593	618.3818859	618.5601072	618.5760964	618.7547076	619.0947709	619.2731871	619.2893714	624.3288987];
Ro_niquel = [1.495978552 1.495978552	1.797587131	2.103217158	2.493297587	2.601876676	2.702412869	3	2.408847185	2.243967828	2.549597855	2.348525469 2.348525469];
R1_niquel = [0.3 0.4609375	1.7265625	2.796875	0.7890625	1.6953125	1.765625	1.0703125	1.140625	0.828125	0.15625	0.0546875 0.03];
C1_niquel = [20 19.58333333	5.833333333	8.125	3.958333333	8.75	5	5.208333333	8.125	5.208333333	14.16666667	61.875 61.875];
R2_niquel = [0.3 0.551822637	2.953853627	1.741904145	2.348607513	1.253238342	0.445910524	0.268134715	0.206930052	0.145725389	0.092292746	0.15544958 0.15544958];
C2_niquel = [0.8 0.798969072	0.310090221	0.169134753	0.053982003	0.081877753	0.159466114	0.277069236	0.330224608	0.460699567	0.681380711	4.278335754 4.2]*1e3;
%% Projeto do controle

%%% Maha fechada controlando vS
% [Kp_i, Ki_i] = Projeto_PI_Corrente(2*pi*fc/10,80);
% [Kp_v, Ki_v] = Projeto_PI_Tensao(2*pi*fc/100,80);

%%% Malha fechada controlando v0
[Kp_i, Ki_i] = Projeto_PI_G(2*pi*fc/100,80,'Gpi_FPB_dTs');   % corrente do interleaved
[Kp_v, Ki_v] = Projeto_PI_Tensao(2*pi*fc/200,80);           

%%% Malha fechada controlando vSC
Kp_v_SC = 0.006283
Ki_v_SC = 3.4451e-1
[Kp_v_SC, Ki_v_SC] = Projeto_PI_G(2*pi*1,80,'Gpv_SC_FPB')

%%% Malha fechada controlando vBatA
[Kp_v_Litio, Ki_v_Litio] = Projeto_PI_G(2*pi*1,89.5,'Gpv_Bat_Litio_FPB')

%%% Malha fechada controlando vBatB
[Kp_v_Sodio, Ki_v_Sodio] = Projeto_PI_G(2*pi*1,89.5,'Gpv_Bat_Sodio_FPB')

%%% Malha fechada controlando iL - inversor
[Kp_i_inv, Ki_i_inv] = Projeto_PI_G(2*pi*fc/20,85,'Gpi_inv');
[Kp_v_inv, Ki_v_inv] = Projeto_PI_G(2*pi*fc/50,80,'Gpv_inv');

%%% Malha fechada controlando Pot
[Kp_pot, Ki_pot] = Projeto_PI_G(2*pi*10,80,'GpPot_Bat_FPB')%%alterando

%%% Malha fechada controlando Vcc
% [Kp_vcc, Ki_vcc] = Projeto_PI_G(226,84.9,'GpPot_Vcc')%%alterando
[Kp_vcc, Ki_vcc] = Projeto_PI_G(2*pi*10,84.9,'GpPot_Vcc')%%alterando

display ('Dados carregados');

% %% Simula��o
% % sim('BoostInterleaved_MalhaAberta_L')
% sim('BoostInterleaved_MalhaFechada_Vcc_Ibat_3con_inv_td')
% n = 'N';
% while (strcmp(n,'N'))
% n = input('Deseja plotar gr�ficos ? Sim (S) ou Nao (N) \n','s');
% end

%% Corrente no indutor
figure (1)
plot(t,iL1,'b',t,iL2,'g','LineWidth',3);
% axis([0.14598 0.14606 0 7]);  % Altera limites do grafico.
grid               % Gera grade.
% title('Grfico f(x) = x*cos(2x)');  % Titulo
xlabel ('Tempo(s)'); % Nome do eixo X
ylabel ('Corrente no indutor (A)'); % Nome do eixo Y
% legend ('legend'); % Legenda

%% Tens�o de sa�da
figure (2)
plot(t,v0,'b','LineWidth',3);
% axis([0.048 0.05 350 450]);  % Altera limites do grafico.
grid                % Gera grade.
% title('Grfico f(x) = x*cos(2x)');  % Titulo
xlabel ('Tempo(s)'); % Nome do eixo X
ylabel ('Tens�o de sa�da (V)'); % Nome do eixo Y
% legend ('legend'); % Legenda

%% Tens�o de entrada
figure (2)
plot(t,vS,'b','LineWidth',3);
% axis([0.048 0.05 350 450]);  % Altera limites do grafico.
grid                % Gera grade.
% title('Grfico f(x) = x*cos(2x)');  % Titulo
xlabel ('Tempo(s)'); % Nome do eixo X
ylabel ('Tens�o de entrada (V)'); % Nome do eixo Y
% legend ('legend'); % Legenda

%% Corrente na carga
figure (3)
plot(t,iR,'b','LineWidth',3);
% axis([0.048 0.05 350 450]);  % Altera limites do grafico.
grid                % Gera grade.
% title('Grfico f(x) = x*cos(2x)');  % Titulo
xlabel ('Tempo(s)'); % Nome do eixo X
ylabel ('corrente na carga (V)'); % Nome do eixo Y
% legend ('legend'); % Legenda

%% Corrente no capacitor
figure (4)
plot(t,iC,'b','LineWidth',3);
% axis([0.048 0.05 350 450]);  % Altera limites do grafico.
grid                % Gera grade.
% title('Grfico f(x) = x*cos(2x)');  % Titulo
xlabel ('Tempo(s)'); % Nome do eixo X
ylabel ('corrente no capacitor (V)'); % Nome do eixo Y
% legend ('legend'); % Legenda
