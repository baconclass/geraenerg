%% --------------------- Tempo total de 7 dias ----------------------------
tempo = 0:1:168;   % 169 pontos

%% --------------------- Índices de 1 dia (24h) ---------------------------
n1 = [1,2,3,4,5,20,21,22,23,24,25];
a1 = [6,7]; 
b1 = [8,9]; 
c1 = [10,11]; 
d1 = [12,13];
e1 = [14,15]; 
f1 = [16,17]; 
g1 = [18,19];

%% --------------------- Vetores semanais -------------------------------
Tensao   = zeros(1,169);
Corrente = zeros(1,169);

%% --------------------- Preencher cada dia ------------------------------
for dia = 0:6   % 7 dias
    offset = dia * 24;

    Tensao(n1+offset) = 0;
    Corrente(n1+offset) = 0;

    Tensao(a1+offset) = 421.838;   Corrente(a1+offset) = 80.8392;
    Tensao(b1+offset) = 430.796;   Corrente(b1+offset) = 201.976;
    Tensao(c1+offset) = 431.538;   Corrente(c1+offset) = 323.228;
    Tensao(d1+offset) = 431.1;     Corrente(d1+offset) = 403.5;
    Tensao(e1+offset) = 431.538;   Corrente(e1+offset) = 323.228;
    Tensao(f1+offset) = 431.381;   Corrente(f1+offset) = 242.453;
    Tensao(g1+offset) = 426.532;   Corrente(g1+offset) = 121.251;
end

%% --------------------- Potência PV ------------------------------------
Potencia_PV = Tensao .* Corrente;

%% --------------------- Curva de carga semanal --------------------------
carga24 = [5 5 10 15 20 50 50 70 70 75 80 85 ...
           85 90 110 130 130 115 70 50 40 35 20 10 5];

% Vetor final da semana: 169 valores
carga = [];

for dia = 1:7
    if dia == 1
        carga = [carga carga24];
    else
        % Remover o primeiro ponto (duplicaria a hora 24)
        carga = [carga carga24(2:end)];
    end
end

carga = carga * 1e3;   % Converter para Watts
%% Exportar dados para Simulink

tempo = tempo * 3600;     % converter horas → segundos

TensaoTs  = timeseries(Tensao,  tempo);
CorrenteTs = timeseries(Corrente, tempo);
CargaTs    = timeseries(carga,    tempo);