clear; clc;

%% 1. CONFIGURAÇÃO DO TEMPO (TEMPO REAL)
% Vetor de 0 a 86400 (24h) com passo de 60 segundos
t = 0 : 60 : 86400; 

%% 2. SEUS DADOS (Pontos Chave)
% Aqui estão os horários e valores exatos que você pediu
horas_chave = [0, 5.9, 6, 7, 8, 9, 10, 11, 12, 13.5, 15, 16.5, 18, 18.1, 24];
irrad_chave = [0,   0, 100, 150, 220, 150, 250, 380, 200, 280, 120,  80,  30,    0,  0];

% Converte horas para segundos (pois o Simulink trabalha em segundos)
segundos_chave = horas_chave * 3600;

%% 3. INTERPOLAÇÃO (Aumentando o vetor)
% O comando 'interp1' preenche os vazios entre seus pontos para criar
% um vetor contínuo de 86400 segundos.
irad_dados = interp1(segundos_chave, irrad_chave, t, 'pchip');

% Garante que não haja valores negativos por erro de cálculo
irad_dados(irad_dados < 0) = 0;

%% 4. CRIANDO A CURVA DE TEMPERATURA
% Temperatura base de 20°C + aquecimento proporcional ao sol
temp_base = 20;
aquecimento = (irad_dados / 400) * 5; % Aquece um pouco onde tem sol
temp_dados = temp_base + aquecimento;

%% 5. PREPARANDO PARA O SIMULINK
% Cria as matrizes [Tempo, Valor]
input_irad = [t' irad_dados']; 
input_temp = [t' temp_dados'];

%% 6. VISUALIZAÇÃO
figure(1);
subplot(2,1,1); 
area(t/3600, irad_dados, 'FaceColor', [1 0.8 0], 'EdgeColor', 'k');
title('Perfil de Irradiância dia chuvoso'); 
xlabel('Horas do Dia'); ylabel('W/m²'); 
grid on; xlim([0 24]); ylim([0 500]); 

subplot(2,1,2); 
plot(t/3600, temp_dados, 'r', 'LineWidth', 2); 
title('Perfil de Temperatura dia chuvoso'); 
xlabel('Horas do Dia'); ylabel('°C');
grid on; xlim([0 24]);

fprintf('Dados gerados com sucesso!\n');
fprintf('Variáveis "input_irad" e "input_temp" criadas no Workspace.\n');