clear; clc;

%% 1. CONFIGURAÇÃO DO TEMPO (TEMPO REAL)
% Agora 1 segundo de simulação = 1 segundo real.
% Vetor de 0 a 86400 (24h * 60m * 60s)
% Passo de 60 segundos (1 minuto) para não deixar a simulação pesada demais
t = 0 : 60 : 86400; 

%% 2. CRIANDO A CURVA DO SOL (Irradiância)
% Lógica em SEGUNDOS:
% Nascer do sol (6h) = 6 * 3600 = 21600 segundos
% Pôr do sol (18h)   = 18 * 3600 = 64800 segundos
% Duração do dia solar = 12 horas = 43200 segundos

nascer_sol = 21600;
por_sol = 64800;
duracao_dia = 43200;

irad_dados = zeros(size(t)); % Começa zerado

for i = 1:length(t)
    tempo_atual = t(i);
    
    if tempo_atual > nascer_sol && tempo_atual < por_sol
        % Fórmula da Senoide ajustada para segundos
        % O termo (pi / duracao_dia) garante que a onda complete o ciclo nas 12h
        irad_dados(i) = 1000 * sin((tempo_atual - nascer_sol) * (pi / duracao_dia));
    else
        irad_dados(i) = 0; % Noite
    end
end

%% 3. CRIANDO A CURVA DE TEMPERATURA
% A temperatura segue a mesma lógica, baseada na irradiância
temp_base = 20;
% Aquece até +15 graus proporcionalmente ao sol
aquecimento = (irad_dados / 1000) * 15; 
temp_dados = temp_base + aquecimento;

%% 4. PREPARANDO PARA O SIMULINK
% Cria as matrizes [Tempo, Valor] que o bloco "From Workspace" exige
input_irad = [t' irad_dados']; 
input_temp = [t' temp_dados'];

%% 5. VISUALIZAÇÃO DOS DADOS
% Plota o gráfico convertendo o eixo X para horas (só para facilitar sua leitura)
figure(1);
subplot(2,1,1); 
plot(t/3600, irad_dados, 'Color', [1 0.8 0], 'LineWidth', 2); 
title('Perfil de Irradiância dia Ensolarado'); 
xlabel('Horas do Dia'); ylabel('W/m²'); 
grid on; xlim([0 24]);

subplot(2,1,2); 
plot(t/3600, temp_dados, 'r', 'LineWidth', 2); 
title('Perfil de Temperatura Ensolarado'); 
xlabel('Horas do Dia'); ylabel('°C');
grid on; xlim([0 24]);

fprintf('Dados gerados com sucesso para 86400 segundos!\n');
fprintf('IMPORTANTE: Altere o "Stop Time" do Simulink para 86400.\n');