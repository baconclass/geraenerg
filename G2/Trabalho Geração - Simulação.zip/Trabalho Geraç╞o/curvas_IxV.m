% 1. Definições Iniciais
temp = 25; % Mantém a temperatura fixa em 25°C
valores_irad = [200, 400, 600, 800, 1000]; % Vetor com as irradiações (W/m2)
cores = {'b', 'g', 'r', 'c', 'k'}; % Cores diferentes para cada linha (opcional)

% Prepara a figura
figure;
title('Curvas I-V para Diferentes Irradiações');
xlabel('Tensão (V)');
ylabel('Corrente (A)');
grid on;
hold on; % Segura o gráfico para desenhar várias linhas juntas

% 2. O Loop FOR
for i = 1:length(valores_irad)
    % Atualiza a variável 'irad' que o Simulink vai ler
    irad = valores_irad(i);
    
    % Roda a simulação
    out = sim('Pv_e_baterias.slx');
    
    % Plota o resultado da rodada atual
    % (Verifique se no seu workspace é 'out.out' ou apenas 'out')
    plot(out.Vpa.data, out.ipa.data, 'DisplayName', sprintf('%d W/m²', irad), 'LineWidth', 2);
    
    fprintf('Simulação para %d W/m² concluída.\n', irad);
end

% Adiciona a legenda para saber quem é quem
legend show;