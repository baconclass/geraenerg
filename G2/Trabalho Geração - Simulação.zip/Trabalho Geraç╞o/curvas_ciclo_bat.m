%% 1. Preparar os dados (Ingredientes)
% Substitua 'out.dados_scope' pelo nome exato da sua variável no Workspace
% O X1 é o tempo e o YMatrix1 são as curvas
X1 = out.Ciclo_bat.time;
YMatrix1 = out.Ciclo_bat.signals.values;

% Parent1 pode ser vazio ([]), é só um parâmetro técnico do MATLAB
Parent1 = [];

%% 2. Chamar a SUA função (O Desenho)
% Isso vai abrir a janela da figura usando exatamente o layout que você gerou
createfigure(X1, YMatrix1, Parent1);

%% 3. Salvar em PDF (O Arquivo)
% Pega a figura atual (gcf = Get Current Figure) e salva
exportgraphics(gcf, 'grafico_simulink_auto.pdf', 'ContentType', 'vector');

fprintf('Gráfico salvo com sucesso como grafico_simulink_auto.pdf!\n');