clear; clc; close all;

%% 1. CONFIGURAÇÃO DE TEMPO
% Vetor de 0 a 24 horas (em segundos)
t_segundos = 0 : 60 : 86400; 
t_horas = t_segundos / 3600; % Eixo X em horas para o gráfico ficar bonito

%% 2. CENÁRIO A: DIA ENSOLARADO (Ideal)
nascer_sol = 6;
por_sol = 18;
duracao_dia = 12;

irad_sol = zeros(size(t_horas));
for i = 1:length(t_horas)
    h = t_horas(i);
    if h > nascer_sol && h < por_sol
        % Pico de 1000 W/m²
        irad_sol(i) = 1000 * sin((h - nascer_sol) * (pi / duracao_dia));
    end
end

% Temperatura Ensolarada (Base 20°C + até 15°C de aquecimento)
temp_sol = 20 + (irad_sol / 1000) * 15;

%% 3. CENÁRIO B: DIA NUBLADO (Seus Pontos Personalizados)
% Pontos que você definiu anteriormente
horas_chave = [0, 5.9, 6, 7.5, 9, 10.5, 12, 13.5, 15, 16.5, 18, 18.1, 24];
irrad_chave = [0,   0, 0, 220, 150, 380, 200, 280, 120,  80,  0,    0,  0];

% Interpolação suave para criar a curva contínua
irad_nublado = interp1(horas_chave, irrad_chave, t_horas, 'pchip');
irad_nublado(irad_nublado < 0) = 0; % Remove erros negativos

% Temperatura Nublada (Base 18°C + aquecimento leve)
temp_nublado = 18 + (irad_nublado / 400) * 5;

%% 4. PLOTAGEM PARA O RELATÓRIO
% Cria uma figura de alta qualidade
figure('Position', [100, 100, 800, 600], 'Color', 'w');

% --- SUBPLOT 1: IRRADIÂNCIA ---
subplot(2,1,1);
hold on;
% Área Ensolarada (Amarelo Fundo)
area(t_horas, irad_sol, 'FaceColor', [1 0.9 0.6], 'EdgeColor', 'none', 'DisplayName', 'Dia Ensolarado (Área)');
% Linha Ensolarada
plot(t_horas, irad_sol, 'Color', [0.9 0.6 0], 'LineWidth', 2, 'DisplayName', 'Perfil Ensolarado');
% Área Nublada (Cinza Azulado)
area(t_horas, irad_nublado, 'FaceColor', [0.6 0.7 0.8], 'EdgeColor', 'none', 'FaceAlpha', 0.8, 'DisplayName', 'Dia Nublado (Área)');
% Linha Nublada
plot(t_horas, irad_nublado, 'Color', [0.2 0.3 0.5], 'LineWidth', 2, 'DisplayName', 'Perfil Nublado');

title('Comparação de Perfis de Irradiância Solar', 'FontSize', 12, 'FontWeight', 'bold');
ylabel('Irradiância (W/m²)', 'FontSize', 10);
legend('Location', 'NorthEast');
grid on;
xlim([0 24]); ylim([0 1100]);
xticks(0:2:24); % Marcações a cada 2 horas

% --- SUBPLOT 2: TEMPERATURA ---
subplot(2,1,2);
hold on;
plot(t_horas, temp_sol, 'r-', 'LineWidth', 2, 'DisplayName', 'Temp. Dia Ensolarado');
plot(t_horas, temp_nublado, 'b--', 'LineWidth', 2, 'DisplayName', 'Temp. Dia Nublado');

title('Variação de Temperatura dos Módulos', 'FontSize', 12, 'FontWeight', 'bold');
xlabel('Horário do Dia (h)', 'FontSize', 10);
ylabel('Temperatura (°C)', 'FontSize', 10);
legend('Location', 'NorthEast');
grid on;
xlim([0 24]); ylim([15 40]);
xticks(0:2:24);

% Salva a imagem automaticamente para você usar no LaTeX
saveas(gcf, 'perfis_comparativos.png');
fprintf('Gráfico gerado e salvo como "perfis_comparativos.png".\n');