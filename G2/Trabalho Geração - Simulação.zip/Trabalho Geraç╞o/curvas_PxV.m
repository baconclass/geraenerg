% 1. Configurações Iniciais
temp = 25; % Temperatura fixa
valores_irad = [200, 400, 600, 800, 1000]; % Irradiações a testar
cores = {'b', 'g', 'm', 'c', 'r'}; % Cores para diferenciar as curvas

% Vetores para guardar os Pontos de Máxima Potência (MPP) para traçar a linha depois
mpp_v = [];
mpp_p = [];

figure;
title('Curvas P-V e Rastreamento de Máxima Potência');
xlabel('Tensão (V)');
ylabel('Potência (W)');
grid on;
hold on;

% 2. O Loop de Simulação
for i = 1:length(valores_irad)
    irad = valores_irad(i);
    
    % Roda a simulação
    out = sim('Pv_e_baterias.slx');
    
    % Coleta os dados (Tensão e Corrente)
    v = out.Vpa.data;
    i_curr = out.ipa.data;
    
    % --- O PULO DO GATO: Calcula a Potência (P = V * I) ---
    p = v .* i_curr; 
    
    % Encontra o valor Máximo (Pico) dessa curva
    [max_p, idx] = max(p); 
    max_v = v(idx); % Acha a tensão onde ocorre a potência máxima
    
    % Guarda esses valores para desenhar a linha de interpolação depois
    mpp_p = [mpp_p, max_p];
    mpp_v = [mpp_v, max_v];
    
    % % Plota a curva P-V normal
    % plot(v, p, 'Color', cores{i}, 'LineWidth', 2, 'DisplayName', sprintf('%d W/m²', irad));
    % 
    % % Marca um "ponto" no pico máximo
    % plot(max_v, max_p, 'ko', 'MarkerFaceColor', 'k', 'HandleVisibility', 'off');
    % 
    % fprintf('Irradiância %d W/m² -> Potência Máxima: %.2f W em %.2f V\n', irad, max_p, max_v);
end

% % 3. Interpolação dos Máximos (Linha de Tendência)
% % Desenha uma linha tracejada conectando todos os picos
% plot(mpp_v, mpp_p, 'k--', 'LineWidth', 1.5, 'DisplayName', 'Curva de MPPT');
% 
% legend('Location', 'NorthWest');
% axis([0 40 0 250]); % Ajuste o Zoom conforme sua necessidade (ex: 0 a 400V se for o arranjo grande)
% hold off;